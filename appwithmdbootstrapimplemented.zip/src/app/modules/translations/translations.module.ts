import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TranslationsRoutingModule } from './translations-routing.module';
import { TranslationsComponent } from './translations.component';

@NgModule({
  imports: [
    CommonModule,
    TranslationsRoutingModule
  ],
  declarations: [TranslationsComponent]
})
export class TranslationsModule { }
