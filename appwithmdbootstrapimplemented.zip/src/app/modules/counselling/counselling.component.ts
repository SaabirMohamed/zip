import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-counselling',
  templateUrl: './counselling.component.html',
  styleUrls: ['./counselling.component.scss']
})
export class CounsellingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
