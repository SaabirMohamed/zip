import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customform',
  templateUrl: './customform.component.html',
  styleUrls: ['./customform.component.scss']
})
export class CustomformComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
