import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule, Validators} from '@angular/forms';
import { CustomformComponent } from '../components/customform/customform.component';
import { FormGroup, FormControl } from '@angular/forms';

@NgModule({
  declarations: [
    CustomformComponent,
    FormGroup,
    FormControl
  ],
  imports: [
    ReactiveFormsModule,
    FormsModule
  ],
  exports: [ReactiveFormsModule, FormsModule, CustomformComponent, FormGroup, FormControl],
  providers: []
})
export class MyglobalsModule { }
