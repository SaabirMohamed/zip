import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthguardGuard } from './modules/authguard.guard';

const routes: Routes = [
  {
    path: '', loadChildren: './modules/home/home.module#HomeModule'
  },
  {
    path: 'counselling', loadChildren: './modules/counselling/counselling.module#CounsellingModule'
  },
  {
    path: 'translations', loadChildren: './modules/translations/translations.module#TranslationsModule'
  },
  {
    path: 'blog', loadChildren: './modules/blog/blog.module#BlogModule'
  },
  {
    path: 'school', loadChildren: './modules/school/school.module#SchoolModule'
  },
  {
    path: 'contacts', loadChildren: './modules/contacts/contacts.module#ContactsModule'
  },
  {
    path: 'about', loadChildren: './modules/about/about.module#AboutModule'
  },
  {
    path: 'controlpanel', loadChildren: './modules/controlpanel/controlpanel.module#ControlpanelModule'
  },
  {
    path: 'login', loadChildren: './modules/login/login.module#LoginModule'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
